var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var routes = require('./routes/index');
var users = require('./routes/users');
var dao = require('./dao/dao.js');
var sd = require('silly-datetime');
var fs = require('fs');
var PORT = 8080;
var app = express();
app.locals.title = '聊天室';
// view engine setup
// view engine setup
app.set('views', path.join(__dirname, 'views'));
//设置模板的后缀是html
app.engine('html', require('ejs').renderFile);
//指定总模板
app.set('view engine', 'html');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);

// -- socket.io  start
var server = http.Server(app);
var io = require('socket.io').listen(server);
var roomUser = {};
//===================socket链接监听=================
io.on('connection', function (socket) {
    // 获取用户当前的url，从而截取出房间id
    var url = socket.request.headers.referer;
    var split_arr = url.split('/');
    var roomid = split_arr[split_arr.length-1] || 'index';
    var user = '';
    socket.on('join', function (username) {
         user = username;
        // 将用户归类到房间
        if (!roomUser[roomid]) {
            roomUser[roomid] = [];
        }
        roomUser[roomid].push(user);
        socket.join(roomid);
        socket.to(roomid).emit('sys', user + '加入了房间');
        socket.emit('sys',user + '加入了房间');
    });
    // 监听来自客户端的消息
    socket.on('message', function (msg) {
        //console.log(s);
        // 验证如果用户不在房间内则不给发送
        if (roomUser[roomid].indexOf(user)< 0) {  
          return false;
        }
        if(msg.startsWith("{")&&msg.endsWith("}")){
            //转为json格式
             var s = JSON.parse(msg);
            //console.log('is json style');
            //console.log(s.MSG);
            var message = s.MSG;
            if(message =="PerPAK"){
                //console.log('ok');
                //获取设备号
                var deviceid = s.NInf.NNum;
                //console.log(deviceid);
                //获取网关号
                var gatewayNumber = s.GWNum;
                //获取数据
                var nodeData = s.NInf.Dat;
                //返回相应信息
                sysmsg = 'GW='+gatewayNumber+'success';
                //socket.to(roomid).emit('new message', msg,user);
                socket.emit('new message', msg,user);
                //系统的回复会出现在所有的连接者
                //socket.to(roomid).emit('sys',sysmsg);
                //这一句相当于跟系统私聊
                socket.emit('sys', '系统回复：'+sysmsg);
                //数据库操作
                dao.upload(deviceid,nodeData);
                socket.emit('sys', '系统回复：数据库插入w_data成功');
            }
            else if(message =="PerHeart"){
                //获取设备号
                var deviceid = s.NInf.NNum;
                 //获取网关号
                var gatewayNumber = s.GWNum;

                //socket.to(roomid).emit('new message', msg,user);
                socket.emit('new message', msg,user);
                dao.heartbeatInsert(deviceid, "online",function(err,result){
                    if (err) {
                        return next(err);
                    }
                    socket.emit('sys', '系统回复：'+result);
                });
                dao.heartbeatUpdate(deviceid, "online",function(err,result){
                    if (err) {
                        return next(err);
                    }
                    socket.emit('sys', '系统回复：'+result);
                });
                dao.nodeGatewayUpdate(deviceid,gatewayNumber,function(err,result){
                    if (err) {
                        return next(err);
                    }
                    socket.emit('sys', '系统回复：'+result);
                });
            }
            else if(message =="PerCTR"){
                //获取设备号
                var deviceid = s.NInf.NNum;
                 //获取网关号
                var gatewayNumber = s.GWNum;
                //获取数据
                var nodeData = s.NInf.Dat;
                //控制反馈信息
                socket.emit('sys', deviceid+'feedback');
            }
            else if(message =="PerEVT"){
                //获取当前系统时间
                var currentTime=sd.format(new Date(), 'YYYY-MM-DD HH:mm');
                console.log(currentTime);
                 //获取网关号
                var gatewayNumber = s.GWNum;
                 //获取设备号
                var deviceid = s.NInf.NNum;
                //获取数据
                var nodeData = s.NInf.Dat;
                 //返回相应信息
                sysmsg = 'GW='+gatewayNumber+'success';
                //socket.to(roomid).emit('new message', msg,user);
                socket.emit('new message', msg,user);
                //系统的回复会出现在所有的连接者
                //socket.to(roomid).emit('sys',sysmsg);
                //这一句相当于跟系统私聊
                socket.emit('sys', '系统回复：'+sysmsg);
                //数据库操作
                dao.upload(deviceid,nodeData);
                socket.emit('sys', '系统回复：数据库插入w_data成功');
            }
        }else{
            console.log('this is not json');
            if(msg.startsWith('S:GW')){
                    //user就是当前分配的用户，是一个八位数的随机数
                    //console.log(user);
                    //获取其长度为8
                    //console.log(user.length);
                    if(user.length == 8){
                        var nodenum=msg.substring(13,19);
                        console.log(nodenum);
                         dao.getNodeGateway(nodenum,function(err,result){
                        if (err) {
                            return next(err);
                        }
                        if(result != 0){
                            //msg:S:GW=901001N=802001#NCTR@Relay=1E;
                            ///g全局不发挥作用？
                            //这里不行！！！！替换不了，可能需要正则表达式进行替换
                            newmsg = msg.replace(/nodenum/g,'888888')
                         //newmsg:S:GW=901001N=888888#NCTR@Relay=1E;
                            console.log(newmsg);
                            socket.emit('sys', '系统回复：'+newmsg);
                        }
                    });
                    }
                }  
        }
        
    });

    // 关闭
    socket.on('disconnect', function () {
        // 从房间名单中移除
        socket.leave(roomid, function (err) {
            if (err) {
                log.error(err);
            } else {
                //将当前时间和八位随机数写进文件中
                //获取当前系统时间
                var currentTime=sd.format(new Date(), 'YYYY-MM-DD HH:mm');
                dataInf = '['+currentTime+']:{'+user+'='+roomid+'};\r\n'
                //文件追加模式来写入多行数据
                fs.appendFile('./log.txt',dataInf,function(err){
                    if(err) throw err;
                    console.log('write has finished');
                });
                var index = roomUser[roomid].indexOf(user);
                if (index !== -1) {
                    roomUser[roomid].splice(index, 1);
                    socket.to(roomid).emit('sys',user+'退出了房间');
                } 
            }
        });
    });
});
// -- socket.io end
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

if (!module.parent) {
    // This server is socket server
    server.listen(PORT);
    console.log('chatroom started up on port '+PORT);
}
module.exports = server;

# chatroom-demo
## 非常简单的socket.io聊天室
### 1.克隆代码到本地后，进入根目录执行node server
### 2.打开浏览器，访问localhost:8080/room/1即可
### 3.如果要打开多个聊天室，则开启多个浏览器tab,访问localhost/room/:d(:d表示所有数字)

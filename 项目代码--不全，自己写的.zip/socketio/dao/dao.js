// dao/userDao.js
// 实现与MySQL交互
var mysql = require('mysql');
var $conf = require('../conf/db');
var $util = require('../util/util');
var crypto = require('crypto')  
var sd = require('silly-datetime');//sd.format(savetime, 'YYYY-MM-DD HH:mm:ss')

// 使用连接池，提升性能
var pool  = mysql.createPool($util.extend({}, $conf.mysql));

// 向前台返回JSON方法的简单封装
var jsonWrite = function (res, ret) {
	if(typeof ret === 'undefined') {
		res.json({
			code: 0,
			msg: '操作失败'
		});
	} else {
		res.json(ret);
	}
};

module.exports = {
	upload: function (nodeNumber, nodeData,req, res, next,callback) {
		pool.getConnection(function(err, connection) {
			// 获取前台页面传过来的参数
			//var param = req.query || req.params;

			// 建立连接，向表中插入值
			// 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
			connection.query('insert into w_data(deviceid, value, savetime) values(?,?,now())', [nodeNumber, nodeData], function(err, result) {
				if(result) {
					result = {
						code: 200,
						msg:'增加成功'
					};    
				}

				// 以json形式，把操作结果返回给前台页面
				//jsonWrite(res, result);

				// 释放连接 
				connection.release();
				//return callback(err,result);
			});
		});
	},

	heartbeatInsert: function (deviceid,heartbeat,callback) {
		pool.getConnection(function(err, connection) {
			// 获取前台页面传过来的参数
			//var param = req.query || req.params;

			// 建立连接，向表中插入值
			// 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
			connection.query('insert into w_heartbeat(deviceid, heartbeat, savetime) values(?,?,now())', [deviceid, heartbeat], function(err, result) {
				if(result) {
					result = '对w_heartbeat数据增加成功';    
				}

				// 以json形式，把操作结果返回给前台页面
				//jsonWrite(res, result);

				// 释放连接 
				connection.release();
				return callback(err,result);
			});
		});
	},

	heartbeatUpdate:function (deviceid,heartbeat,callback) {
		pool.getConnection(function(err, connection) {
			// 获取前台页面传过来的参数
			//var param = req.query || req.params;

			// 建立连接，向表中插入值
			// 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
			connection.query('update w_deviceinstance set heartbeat=? where deviceid=?',[heartbeat,deviceid], function(err, result) {
				if(result) {
					result = '对w_deviceinstance表更新成功';    
				}

				// 以json形式，把操作结果返回给前台页面
				//jsonWrite(res, result);

				// 释放连接 
				connection.release();
				return callback(err,result);
			});
		});
	},


	nodeGatewayUpdate:function (nodenum,gwnum,callback) {
		pool.getConnection(function(err, connection) {
			// 获取前台页面传过来的参数
			//var param = req.query || req.params;

			// 建立连接，向表中插入值
			// 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
			connection.query('update w_endpointgw set gwnum=? where deviceid=?', [gwnum,nodenum], function(err, result) {
				//
				console.log(result);
				console.log(result.changedRows);
				if(result.changedRows == 1) {
					 result = '对w_endpointgw表更新成功'; 
					 connection.release();
					return callback(err,result);  
				}else if(result.changedRows == 0 && result.affectedRows == 0){
					connection.query('insert into w_endpointgw values(?,?)', [nodenum,gwnum], function(err, result) {
						if(result) {
							result = '对w_endpointgw表插入成功';  
							connection.release();
							return callback(err,result); 
						}
					});	
				}else{
					result = '您插入的数据没有改变,不作任何操作';
					connection.release();
					return callback(err,result); 
				}

				// 以json形式，把操作结果返回给前台页面
				//jsonWrite(res, result);

				// 释放连接 
				
			});
		});
	},

	getNodeGateway:function (nodenum,callback) {
		pool.getConnection(function(err, connection) {
			connection.query('select gwnum from w_endpointgw where deviceid=?', nodenum, function(err, result) {
				if(result) {
					result = {
						msg:result
					};    
				}
				//jsonWrite(res, result);
				connection.release();
				return callback(err,result); 
			});
		});
	}


};

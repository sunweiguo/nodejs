var express = require('express');
var router = express.Router();
var dao = require('../dao/dao');
var sd = require('silly-datetime');

/* GET home page. */
router.get('/websocket/:id', function(req, res, next) {
  res.render('index');
});

module.exports = router;

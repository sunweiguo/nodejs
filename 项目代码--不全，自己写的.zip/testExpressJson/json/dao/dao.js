// dao/userDao.js
// 实现与MySQL交互
var mysql = require('mysql');
var $conf = require('../conf/db');
var $util = require('../util/util');
var crypto = require('crypto')  
var sd = require('silly-datetime');//sd.format(savetime, 'YYYY-MM-DD HH:mm:ss')
var tools = require('../tools/tools');


// 使用连接池，提升性能
var pool  = mysql.createPool($util.extend({}, $conf.mysql));

// 向前台返回JSON方法的简单封装
var jsonWrite = function (res, ret) {
	if(typeof ret === 'undefined') {
		res.json({
			code: 0,
			msg: '操作失败'
		});
	} else {
		res.json(ret);
	}
};

//md5
var md5 = function(data) {
    var Buffer = require("buffer").Buffer;
    var buf = new Buffer(data);
    var str = buf.toString("binary");
    var crypto = require("crypto");
    return crypto.createHash("md5WithRSAEncryption").update(str).digest("hex");
}

module.exports = {
	add: function (req, res, next,callback) {
		pool.getConnection(function(err, connection) {
			// 获取前台页面传过来的参数
			var param = req.query || req.params;

			// 建立连接，向表中插入值
			// 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
			connection.query('INSERT INTO user(id, name, age) VALUES(0,?,?)', [param.name, param.age], function(err, result) {
				if(result) {
					result = {
						code: 200,
						msg:'增加成功'
					};    
				}

				// 以json形式，把操作结果返回给前台页面
				jsonWrite(res, result);

				// 释放连接 
				connection.release();
				return callback(err,result);
			});
		});
	},
	queryAll: function (req, res, next,callback) {
		pool.getConnection(function(err, connection) {
			connection.query('select * from w_user', function(err, result) {
				if(result) {
					result = {
						code: 200,
						msg:result
					};    
				}
				//console.log(result.code);
				jsonWrite(res, result);
				
				connection.release();
				return callback(err,result);
			});
		});
	},
	queryById: function (req, res, next) {
		var id = +req.query.id; // 为了拼凑正确的sql语句，这里要转下整数
		console.log('id='+id);
		pool.getConnection(function(err, connection) {
			connection.query('select * from user where id=?', id, function(err, result) {
				if(result) {
					result = {
						code: 200,
						msg:result
					};    
				}
				jsonWrite(res, result);
				connection.release();

			});
		});
	},
	delete: function (req, res, next) {
		// delete by Id
		pool.getConnection(function(err, connection) {
			var id = +req.query.id;
			connection.query('delete from user where id=?', id, function(err, result) {
				if(result.affectedRows > 0) {
					result = {
						code: 200,
						msg:'删除成功'
					};
				} else {
					result = void 0;
				}
				jsonWrite(res, result);
				connection.release();
			});
		});
	},
	update: function (req, res, next) {
		// update by id
		// 为了简单，要求同时传name和age两个参数
		var param = req.query;
		if(param.name == null || param.age == null || param.id == null) {
			return;
		}

		pool.getConnection(function(err, connection) {
			connection.query('update user set name=?, age=? where id=?', [param.name, param.age, param.id], function(err, result) {
					result = {
						code: 200,
						msg:'更新成功'
					};
					jsonWrite(res, result);
					connection.release();
			});
		});

	},







	islegalUser:function (username,password,req, res, next,callback) {
		pool.getConnection(function(err, connection) {
			//var param = req.query || req.params;
			// 建立连接，向表中插入值
			// 'INSERT INTO user(id, name, age) VALUES(0,?,?)',
			connection.query('select * from w_user where username=?',username, function(err, result) {
				/*测试代码，通过get标准方式进行测试
				console.log("输入的密码是:"+param.password);
				var s1 = md5(param.password);
				console.log("输入密码MD5加密后:"+s1);
				console.log("数据库密码是:"+result[0].password);
				var s2 = result[0].password;
				console.log("数据库密码MD5加密后:"+md5(s2));
				console.log(typeof s1);
				console.log(param.password == result[0].password);
				if(param.password == result[0].password){
					if(result) {
						result = {
							code: 200,
							msg:'密码认证通过'
						};
					}
				}*/
				//等待参数的输入，对密码进行验证
				console.log("输入的密码是:"+password);
				var s1 = md5(password);
				console.log("输入密码MD5加密后:"+s1);
				console.log("数据库密码是:"+result[0].password);
				var s2 = result[0].password;
				console.log("数据库密码MD5加密后:"+md5(s2));
				console.log(typeof s1);
				console.log(password == result[0].password);
				if(password == result[0].password){//这边有问题，应该是md5的比较
					if(result) {
						result = {
							code:result[0].userid
						};
					}
				}else{
					return 0;
				}
				// 以json形式，把操作结果返回给前台页面
				jsonWrite(res, result);

				// 释放连接 
				connection.release();
				return callback(err,result);
			});
		});
	},


	inserthandle:function (handle,userid,req, res, next,callback) {
		pool.getConnection(function(err, connection) {
			// 获取前台页面传过来的参数
			//var param = req.query || req.params;

			// 建立连接，向表中插入值
			// 尤其要注意这里的handle在模拟输入的时候是不能重复的，因为是主键
			connection.query('insert into w_authority values(?,now(),now()+1000,?,1)',[handle,userid], function(err, result) {
				if(result) {
					result = {
						code: 200,
						msg:'增加成功'
					};    
				}
				// 以json形式，把操作结果返回给前台页面
				//jsonWrite(res, result);

				// 释放连接 
				connection.release();
				return callback(err,result);
			});
		});
	},

	islegalhandle:function (req, res, next) {
		pool.getConnection(function(err, connection) {
			var param = req.query || req.params;
			// 建立连接，向表中插入值
			connection.query('select * from w_authority where handle=?', [param.handle], function(err, result) {
				//console.log(err);
				console.log("输入的句柄是:"+ [param.handle]);
				if(result) {
					var time = result[0].endtime;
					var endTime=sd.format(time, 'YYYY-MM-DD HH:mm:ss');
					var currentTime=sd.format(new Date(), 'YYYY-MM-DD HH:mm:ss');
					console.log('endtime:'+endTime);
					console.log('currentTime:'+currentTime);

					console.log(tools.dateCompare(currentTime,endTime,req,res,next));
					//日期的比较
					if(tools.dateCompare(currentTime,endTime,req,res,next)){
						result = {
							code: 200,
							msg:'true'
						};
					}
					else{
						result = {
							code: 200,
							msg:'false'
						};
					}
					}

				// 以json形式，把操作结果返回给前台页面
				jsonWrite(res, result);

				// 释放连接 
				connection.release();
				//return callback(err,result);
			});
		});
	},

	updatehandle:function(req,res,next){
		var param = req.query;
		pool.getConnection(function(err, connection) {
			connection.query('update w_authority set endtime=now(),survivaltime=(now()-begintime)*24 where handle=?', param.handle, function(err, result) {
					result = {
						code: 200,
						msg:'更新成功'
					};
					jsonWrite(res, result);
					connection.release();
			});
		});
	},

	getCurrentValue:function (req, res, next,callback) {
		var param = req.query;
		pool.getConnection(function(err, connection) {
			connection.query('select * from(select value,savetime from w_data where deviceid=? order by savetime desc) as data limit 1',[param.deviceid], function(err, result) {
				/*if(result) {
					result = {
						code: 200,
						msg:result
					};    
				}*/
				//console.log(result.code);
				jsonWrite(res, result);
				
				connection.release();
				return callback(err,result);
			});
		});
	},

	getSenorPara:function (req, res, next,callback) {
		var param = req.query;
		pool.getConnection(function(err, connection) {
			connection.query('select value from(select value,savetime from w_data where deviceid=? order by savetime desc) as data limit 1',[param.deviceid], function(err, result) {
				/*if(result) {
					result = {
						code: 200,
						msg:result
					};    
				}*/
				//console.log(result.code);
				jsonWrite(res, result);
				
				connection.release();
				return callback(err,result);
			});
		});
	},

	getLatestSaveTime:function (req, res, next,callback) {
		var param = req.query;
		pool.getConnection(function(err, connection) {
			connection.query('SELECT savetime FROM(SELECT * FROM w_data WHERE deviceid=? ORDER BY savetime DESC) AS DATA LIMIT 1',param.deviceid, function(err, result) {
				/*if(result) {
					result = {
						code: 200,
						msg:result
					};    
				}*/
				//console.log(result.code);
				jsonWrite(res, result);
				
				connection.release();
				return callback(err,result);
			});
		});
	},

	getLocationValues:function (req, res, next,callback) {
		var param = req.query;
		var deviceID_start = param.deviceID_start;
		var deviceID_end = param.deviceID_end;
		var count = (deviceID_end - deviceID_start + 1);
		function StringBuffer() {
		    this.__strings__ = new Array();
		}
		StringBuffer.prototype.append = function (str) {
		    this.__strings__.push(str);
		    return this;    //方便链式操作
		}
		StringBuffer.prototype.toString = function () {
		    return this.__strings__.join("");
		}
		var buffer = new StringBuffer();
		pool.getConnection(function(err, connection) {
			connection.query( "select * from (select deviceid, value, savetime from w_data where deviceid between ? and ? order by savetime desc) as d"
				 + " order by deviceid limit "+ count,[deviceID_start,deviceID_end], function(err, result) {
				//var buffer = new StringBuffer();
				//获取各个字段值
				console.log(result.length);
				var strings = '';
				for(var i = 0; i<result.length; i++){
					var deviceid = new String(result[i].deviceid);
					console.log(deviceid.toString());

					var value = new String(result[i].value);
					console.log(value.toString());

					var savetime = new String(result[i].savetime);
					console.log(savetime.toString());

					strings =buffer.append(deviceid+':'+value+':'+sd.format(savetime, 'YYYY-MM-DD HH:mm:ss')+';');
					
				}
				//console.log(strings.toString());
				result = strings;
				jsonWrite(res, result);
				connection.release();
				return callback(err,result);
			});
		});
	},

	getRecentValues:function (req, res, next,callback) {
		var param = req.query;
		function StringBuffer() {
		    this.__strings__ = new Array();
		}
		StringBuffer.prototype.append = function (str) {
		    this.__strings__.push(str);
		    return this;    //方便链式操作
		}
		StringBuffer.prototype.toString = function () {
		    return this.__strings__.join("");
		}
		var buffer = new StringBuffer();
		pool.getConnection(function(err, connection) {
			connection.query( "SELECT * FROM (SELECT savetime, value FROM w_data WHERE deviceid=? ORDER BY savetime DESC) AS d LIMIT 10",
								param.deviceid, function(err, result) {
				//var buffer = new StringBuffer();
				//获取各个字段值
				console.log(result.length);
				var strings = '';
				for(var i = 0; i<result.length; i++){
					var savetime = new String(result[i].savetime);
					var value = new String(result[i].value);

					strings =buffer.append(sd.format(savetime, 'YYYY-MM-DD HH:mm:ss')+'#'+value+';');
					
				}
				//console.log(strings.toString());
				result = strings;
				jsonWrite(res, result);
				connection.release();
				return callback(err,result);
			});
		});
	},

	getSensorOnedayRecord:function (req, res, next,callback) {
		var param = req.query;
		function StringBuffer() {
		    this.__strings__ = new Array();
		}
		StringBuffer.prototype.append = function (str) {
		    this.__strings__.push(str);
		    return this;    //方便链式操作
		}
		StringBuffer.prototype.toString = function () {
		    return this.__strings__.join("");
		}
		var buffer = new StringBuffer();
		pool.getConnection(function(err, connection) {
			connection.query( "SELECT savetime, value FROM w_data WHERE DATE_FORMAT(savetime,'%Y-%m-%d')= DATE_FORMAT(?,'%Y-%m-%d')  AND deviceid=? ORDER BY savetime",
								[param.time,param.deviceid], function(err, result) {
				//var buffer = new StringBuffer();
				//获取各个字段值
				console.log(result.length);
				var strings = '';
				for(var i = 0; i<result.length; i++){
					var savetime = new String(result[i].savetime);
					var value = new String(result[i].value);

					strings =buffer.append(sd.format(savetime, 'YYYY-MM-DD HH:mm:ss')+','+value+';');
					
				}
				//console.log(strings.toString());
				result = strings;
				jsonWrite(res, result);
				connection.release();
				return callback(err,result);
			});
		});
	},

	getChildLocationID:function (req, res, next,callback) {
		var param = req.query;
		function StringBuffer() {
		    this.__strings__ = new Array();
		}
		StringBuffer.prototype.append = function (str) {
		    this.__strings__.push(str);
		    return this;    //方便链式操作
		}
		StringBuffer.prototype.toString = function () {
		    return this.__strings__.join("");
		}
		var buffer = new StringBuffer();
		pool.getConnection(function(err, connection) {
			connection.query( "SELECT LOCATIONID,LOCATION,LONGITUDE,LATITUDE,Areaid FROM(SELECT L1.LOCATIONID,L1.LOCATION,L1.PARENTID,L2.LOCATIONID AS loc2id,L2.LOCATION AS loc2,L2.PARENTID AS loc2pid ,L1.Longitude,L1.LATITUDE,L1.Areaid FROM W_LOCATION L1,W_LOCATION L2 WHERE L1.PARENTID=L2.LOCATIONID ORDER BY L1.LOCATIONID) AS d WHERE loc2id=?",
								param.locationID, function(err, result) {
				//var buffer = new StringBuffer();
				//获取各个字段值
				var strings = '';
				for(var i = 0; i<result.length; i++){
					var LOCATIONID = new String(result[i].LOCATIONID);
					var LOCATION = new String(result[i].LOCATION);
					var Longitude = new String(result[i].Longitude);
					var LATITUDE = new String(result[i].LATITUDE);
					var Areaid = new String(result[i].Areaid);

					strings =buffer.append(LOCATIONID+':'+LOCATION+':'+Longitude+':'+LATITUDE+':'+Areaid+';');
					
				}
				//console.log(strings.toString());
				result = strings;
				jsonWrite(res, result);
				connection.release();
				return callback(err,result);
			});
		});
	},

	getAllChildLocationID:function (req, res, next,callback) {
		var param = req.query;
		function StringBuffer() {
		    this.__strings__ = new Array();
		}
		StringBuffer.prototype.append = function (str) {
		    this.__strings__.push(str);
		    return this;    //方便链式操作
		}
		StringBuffer.prototype.toString = function () {
		    return this.__strings__.join("");
		}
		var buffer = new StringBuffer();
		pool.getConnection(function(err, connection) {
			connection.query( "SELECT LOCATIONID,LOCATION FROM(SELECT L1.LOCATIONID,L1.LOCATION,L1.PARENTID,L2.LOCATIONID AS loc2id,L2.LOCATION AS loc2,L2.PARENTID AS loc2pid FROM W_LOCATION L1,W_LOCATION L2 WHERE L1.PARENTID=L2.LOCATIONID ORDER BY L1.LOCATIONID) AS d WHERE loc2id=?",
								param.locationID, function(err, result) {
				//var buffer = new StringBuffer();
				//获取各个字段值
				var strings = '';
				for(var i = 0; i<result.length; i++){
					var LOCATIONID = new String(result[i].LOCATIONID);
					var LOCATION = new String(result[i].LOCATION);

					strings =buffer.append(LOCATIONID+':'+LOCATION+';');
					
				}
				//console.log(strings.toString());
				result = strings;
				jsonWrite(res, result);
				connection.release();
				return callback(err,result);
			});
		});
	},


};
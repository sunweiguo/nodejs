var express = require('express');
var router = express.Router();
var dao = require('../dao/dao');
var tools = require('../tools/tools');
var sd = require('silly-datetime');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//用户验证


// 增加用户
router.post('/addUser', function(req, res, next) {
	dao.add(req, res, next,function(err,users){
		 if (err) {

                return next(err);
            }
            var head = users.code;
            console.log(head);
	});
});

router.get('/queryAll', function(req, res, next) {
	dao.queryAll(req, res, next,function(err,users){
            if (err) {

                return next(err);
            }
            var head = users.code;
            console.log(head);
            /*for(var i = 0;i<users.msg.length ;i++){
            		console.log(users.msg[i].name);
            }*/
        });
});
router.get('/queryById', function(req, res, next) {
	dao.queryById(req, res, next);
});
router.get('/deleteUser', function(req, res, next) {
	dao.delete(req, res, next);
});
router.post('/updateUser', function(req, res, next) {
	dao.update(req, res, next);
});

//插入句柄
router.post('/1',function(req, res, next) {
    var param = req.query;
    var handle = param.handle;
    var userid = param.userid;
	dao.inserthandle(handle,userid,req, res, next,function(err,users){
		 if (err) {
                return next(err);
            }
           var head = users.code;
           console.log(head);
	});
});
//验证是否是合法用户
router.get('/2',function(req, res, next) {
    var param = req.query;
    var username = param.username;
    var password = param.password;
    console.log(username);
	dao.islegalUser(username,password,req, res, next,function(err,users){
		 if (err) {
                return next(err);
            }
          console.log("查询到的userid是："+users.code);
          var userid = users.code;
         if(userid > 0){
            //正则表达式将所有的-去掉
            console.log(tools.getRandomNumber().toString().replace(/\-/g,''));
            var handle = tools.getRandomNumber().toString().replace(/\-/g,'');
           console.log("句柄是："+handle);
           console.log("用户id是："+userid);
            //插入数据
           dao.inserthandle(handle,userid,req, res, next,function(err,users){
            if (err) {
                return next(err);
            }
         });
         	console.log('是合法用户');
         }
	});
});

//检测句柄是否合法及有效
router.get('/3',function(req,res,next){
    dao.islegalhandle(req,res,next);
});

//更新句柄内容
router.post('/4',function(req,res,next){
    dao.updatehandle(req,res,next);
});

//查询传感器的指定数据+保存时间
router.get('/5',function(req,res,next){
    dao.getCurrentValue(req,res,next,function(err,users){
        //输出value值
        console.log(users[0].value+":"+users[0].savetime);
    });
});

//查询所有传感器的指定数据
router.get('/6',function(req,res,next){
    dao.getSenorPara(req,res,next,function(err,users){
        //输出value值
        console.log(users[0].value);
    });
});

//查询指定传感器最近一条数据的存储时间
router.get('/7',function(req,res,next){
    dao.getLatestSaveTime(req,res,next,function(err,users){
        var savetime = sd.format(users[0].savetime, 'YYYY-MM-DD HH:mm:ss')
        //输出savetime值
        console.log(savetime);
    });
});


router.get('/8',function(req,res,next){
    dao.getLocationValues(req,res,next,function(err,strings){
        //输出savetime值
        console.log(strings.toString());
    });
});

router.get('/9',function(req,res,next){
    dao.getRecentValues(req,res,next,function(err,strings){
        //输出savetime值
        console.log(strings.toString());
    });
});

router.get('/10',function(req,res,next){
    dao.getSensorOnedayRecord(req,res,next,function(err,strings){
        //输出savetime值
        console.log(strings.toString());
    });
});

router.get('/11',function(req,res,next){
    dao.getChildLocationID(req,res,next,function(err,strings){
        //输出savetime值
        console.log(strings.toString());
    });
});

router.get('/12',function(req,res,next){
    dao.getAllChildLocationID(req,res,next,function(err,strings){
        //输出savetime值
        console.log(strings.toString());
    });
});

router.get('/13',function(req,res,next){
    dao.getSensorsAttrByLocID(req,res,next,function(err,strings){
        //输出savetime值
        console.log(strings.toString());
    });
});
module.exports = router;

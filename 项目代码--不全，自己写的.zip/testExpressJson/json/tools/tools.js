var uuid = require('node-uuid');
module.exports = {
	getMD5Str:function(req, res, next,callback) {
		
	},
	dateCompare:function(currentTime,endTime,req, res, next){
		if(Date.parse(currentTime) - Date.parse(endTime) < 0){
			return true;
			//console.log("在规定时间内");
	    }
		else{
			//console.log("在规定时间外");
			return false;
		}
	},
	getRandomNumber:function(req, res, next){
		return uuid.v4();
	}
};
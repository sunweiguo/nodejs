var mysql = require('mysql');
function mysqlpool(){
	this.flag = true;
	this.pool = mysql.createPool({
		host:'localhost',
		user:'root',
		password:'root',
		database:'node',
		port:'3306'
	});

	this.getPool = function(){
		if(this.flag){
			this.pool.on('connection',function(connection){
				connection.query('set session auto_increment_increment=1');
				this.flag = false;
			})
		}
		return this.pool;
	}
};
module.exports = mysqlpool;
//这样就创建好了一个连接池，便于被调用
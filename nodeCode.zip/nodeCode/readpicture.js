var http = require('http');
var optfile = require('./readfile02.js');
http.createServer(function(request,response){
	response.writeHead(200,{'Content-Type':'image/jpeg'});
	if(request.url!='/favicon.ico'){
		optfile.readImg('1.jpg',response);
	}
}).listen(8000);
console.log('server running at http://localhost:8000');
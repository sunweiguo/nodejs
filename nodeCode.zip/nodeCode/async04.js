var async = require('async');
//瀑布流
function exec(){
	async.waterfall(
		[
			function(done){
				ii = 0;
				setInterval(function(){
					console.log('aaa='+new Date());
					ii++;
					if(ii == 3){
						clearInterval(this);
						done(null,'one finish');//没有错误发生时
						//done('errr','one finish');//有错误发生时
					}
				},1000);
				
			},
			function(preValue,done){
				jj = 0;
				setInterval(function(){
					console.log(preValue+'='+new Date());
					jj++;
					if(jj == 3){
						clearInterval(this);
						done(null,preValue+',two finish');
					}
				},1000);
				
			}
		],function(err,rs){
			console.log(err);
			console.log(rs);
		}
	)
}
exec();
console.log('finish');
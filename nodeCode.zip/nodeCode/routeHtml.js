var http = require('http');
var url  = require('url');
var router = require('./route_readfile02.js')
http.createServer(function(request,response){
	if(request.url!='/favicon.ico'){
		var pathname = url.parse(request.url).pathname;
		pathname = pathname.replace(/\//,'');//这样就将多余的这个斜杠去掉了
		router[pathname](request,response);
	}
}).listen(8000);
console.log('server running at http://localhost:8000');
var events = require('events');
var http = require('http');
function userEvent(){
	//事件发生器
	this.eventEmit = new events.EventEmitter();
	this.zhuce = function(req,res){
		console.log('注册');
		//req['uname'] = 'aa';
		//req['pwd'] = '123';
		this.eventEmit.emit('zhuce','aa','123');//抛出事件消息
	},
	this.login = function(req,res){
		console.log('登陆');
		res.write('用户名:'+req['uname']);
		res.write('密码:'+req['pwd']);
		res.write('登陆');
	}
}
module.exports = userEvent;
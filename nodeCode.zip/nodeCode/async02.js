var async = require('async');
//串行无关联
function exec(){
	async.series(
		{
			one:function(done){
				ii = 0;
				setInterval(function(){
					console.log('aaa='+new Date());
					ii++;
					if(ii == 3){
						clearInterval(this);
						done(null,'one finish');//没有错误发生时
						//done('errr','one finish');//有错误发生时
					}
				},1000);
				
			},
			two:function(done){
				jj = 0;
				setInterval(function(){
					console.log('bbb='+new Date());
					jj++;
					if(jj == 3){
						clearInterval(this);
						done(null,'two finish');
					}
				},1000);
				
			}
		},function(err,rs){
			console.log(err);
			console.log(rs);
		}
	)
}
exec();
console.log('finish');
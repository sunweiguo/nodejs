var User = require('./model.js');
function Teacher(id,name,age){
	User.apply(this,[id,name,age]);
	this.teach = function(res){
		res.write(this.name+'teacher is teaching');
	}
}

module.exports = Teacher;
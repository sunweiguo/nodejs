var fs = require('fs');
var data = fs.readFileSync('1.txt','UTF-8');
console.log(data);
console.log('end');
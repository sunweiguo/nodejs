var fs = require('fs');
fs.readFile('1.txt','UTF-8',function(err,data){
	if(err){
		console.log('error');
	}else{
		console.log(data);
	}
})
console.log('end');
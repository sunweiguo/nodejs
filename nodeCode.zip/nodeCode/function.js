var http = require('http');
var otherfun = require('./functionModel.js')
http.createServer(function (request,response){
	response.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
	if(request.url!='/favicon.ico'){//不加这一句会访问两次
		fun1(response);
		//两种不同的调用方式
		otherfun.fun2(response);//用字符串调用对应的函数
		otherfun['fun3'](response);

		fname = 'fun4';//赋予不同的值调用不同的函数
		otherfun[fname](response);
		response.end();
	}
}).listen(8000);
console.log('server running at http://localhost:8000');
//本地函数直接调用
function fun1(res){
	console.log('fun1');
	res.write('hello fun1');
}
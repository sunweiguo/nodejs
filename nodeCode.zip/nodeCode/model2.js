var http = require('http');
var User = require('./model.js')
var Teacher = require('./Teacher')
http.createServer(function (request,response){
	response.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
	if(request.url!='/favicon.ico'){//不加这一句会访问两次
		/*user = new User();
		user.id = 1;
		user.name = 'zs';
		user.age = 20;
		user.enter();*/

		teacher = new Teacher();
		teacher.id = 11;
		teacher.name = 'zs老师';
		teacher.age = 20;
		teacher.enter();
		teacher.teach(response);

		//构造函数
		/*user1 = new User(2,'李四',30);
		user1.enter();
		response.end();*/
	}
}).listen(8000);
console.log('server running at http://localhost:8000');
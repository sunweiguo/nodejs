module.exports = {
	login:function(req,res){
		res.write('我是登陆方法');
	},
	register:function(req,res){
		res.write('我是注册方法');
	}
}
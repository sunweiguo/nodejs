var http = require('http');
var optfile = require('./readfile02.js');
http.createServer(function(request,response){
	response.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
	if(request.url!='/favicon.ico'){
		//optfile.readfileSync('login.txt');

		optfile.readfile('register.txt',recall);
		function recall(data){
			response.write('hello');
			response.end()
		}
		
		console.log('主程序已经执行完毕');
	}
}).listen(8000);
console.log('server running at http://localhost:8000');
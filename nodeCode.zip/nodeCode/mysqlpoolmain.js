var mysqlpool = require('./mysqlpool.js');
var mysqlpool = new mysqlpool();
var pool = mysqlpool.getPool();

pool.getConnection(function(err,conn){
	var userAdd = 'insert into user(uname,pwd) values(?,?)';
	var param = ['naina','456'];
	//插入
	conn.query(userAdd,param,function(err,rs){
	if(err){
		console.log('insert err'+err.message);
		return;
	}
	console.log('insert succeed');
	//conn.release();
})
	//查询s
	conn.query('select * from user',function(err,rs){
	if(err){
		console.log('insert err'+err.message);
		return;
	}
	for(var i=0; i<rs.length; i++){
		console.log(rs[i]);
	}
	conn.release();
})
})
function User(){
	this.id;
	this.name;
	this.age;
	this.enter = function(){
		console.log(this.name+' enter the library');
	}
}
function UserCons(id,name,age){
	this.id = id;
	this.name = name;
	this.age = age;
	this.enter = function(){
		console.log(this.name+' enter the library');
	}
}
module.exports = User;
function fun1(){
	/*setTimeout(function(){

	},1000);*/
	ii = 0;
	setInterval(function(){
		console.log('aaa='+new Date());
		ii++;
		if(ii == 3){
			clearInterval(this);
		}
	},1000);
	console.log('fun1');
};
function fun2(){
	jj = 0;
	setInterval(function(){
		console.log('bbb='+new Date());
		jj++;
		if(jj == 3){
			clearInterval(this);
		}
	},1000);
	console.log('fun2');
};
fun1();
fun2();
console.log('finish');


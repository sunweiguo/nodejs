var mysql = require('mysql');
//创建一个connection对象
var connection = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'root',
	database:'node',
	port:'3306'
});
//执行connection
connection.connect(function(err){
	if(err){
		//连接不成功
		console.log('[query]-:'+err);
		return;
	}
	//连接成功
	console.log('[connection connect] succeed!');
});

//执行插入sql
var userAdd = 'insert into user(uname,pwd) values(?,?)';
var param = ['xf','123'];
connection.query(userAdd,param,function(err,rs){
	if(err){
		console.log('insert err'+err.message);
		return;
	}
	console.log('insert succeed');
})
//执行查询
connection.query('select * from user',function(err,rs){
	if(err){
		console.log('query err'+err.message);
		return;
	}
	console.log('result:',rs[0].uname);
})
//关闭connection
connection.end(function(err){
	if(err){
		//连接不成功
		console.log(err.toString());
		return;
	}
	console.log('[connection close] succeed!');
});
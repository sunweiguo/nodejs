var sd = require('silly-datetime');

var time=sd.format(new Date(), 'YYYY-MM-DD HH:mm:ss');
console.log(time);
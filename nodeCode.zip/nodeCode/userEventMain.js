var http = require('http');
var events = require('events');
var userEvent = require('./userEvent.js');
http.createServer(function(request,response){
	response.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
	if(request.url!='/favicon.ico'){
		user = new userEvent();
		user.eventEmit.once('zhuce',function(uname,pwd){
			response.write('注册成功');
			console.log('uname:'+uname);
			console.log('pwd:'+pwd);
			user.login(request,response);
		});
		user.zhuce(request,response);
	}
}).listen(8000);
console.log('server running at http://localhost:8000');
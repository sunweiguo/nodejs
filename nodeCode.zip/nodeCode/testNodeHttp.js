var http = require("http")
http.createServer(function(req,res){
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write('<h1>hello node？</h1>');
	res.end('<p>结束了？</p>');
}).listen(9898);
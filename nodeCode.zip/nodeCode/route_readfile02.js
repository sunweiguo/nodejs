var optfile = require('./readfile02.js');
var url = require('url');
var querystring =  require('querystring');//post提交方式
function getRecall(req,res){
	res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
	function recall(data){
		res.write(data);
		res.end();
	}
	return recall;
}
module.exports = {
	login:function(req,res){
		/*get提交方式
		var rdata = url.parse(req.url,true).query;
		if(rdata['username']!=undefined){
			console.log(rdata['username']);
			console.log(rdata['password']);
		}*/
		//post方式
		var post = '';
		req.on('data',function(chunk){//data事件监听,接收到的信息就会存到post变量中
			post += chunk;
		});
		req.on('end',function(){//end事件触发后，通过querystring.parse将其解析为post格式向客户端返回,异步，最后执行完毕
			post = querystring.parse(post);
			//console.log('收到参数'+post['username'+'\n']);
			//console.log('收到参数'+post['password'+'\n']);
			arr = ['username','password'];
			//recall = getRecall(req,res);
			function recall(data){
				res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
				dataStr = data.toString();
				for(var i = 0; i < arr.length; i++){
					re = new RegExp('{'+arr[i]+'}','g');
					dataStr = dataStr.replace(re,post[arr[i]]);
				}
				res.write(dataStr);
				res.end();
			}
			optfile.readfile('login.html',recall);
		});
		//用闭包实现共有的一个方法
		
	},
	register:function(req,res){
		function recall(data){
			res.write(data);
			res.end();
		}
		optfile.readfile('register.txt',recall);
	},
	writefile:function(req,res){
		function recall(data){
			res.write(data);
			res.end();
		}
		optfile.writefile('write.txt','hello write file',recall);
	},
	showImg:function(req,res){
		res.writeHead(200,{'Content-Type':'image/jpeg'});
		optfile.readImg('1.jpg',res);
	}
}
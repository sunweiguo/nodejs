var http = require('http');
var url  = require('url');
var router = require('./route_readfile02.js')
var exception = require('./exception02.js')
http.createServer(function(request,response){
	if(request.url!='/favicon.ico'){
		var pathname = url.parse(request.url).pathname;
		pathname = pathname.replace(/\//,'');//这样就将多余的这个斜杠去掉了
		try{
			router[pathname](request,response);
		}catch(err){
			console.log(err);
			response.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
			response.write(err.toString());
			response.end();
		}
		
	}
}).listen(8000);
console.log('server running at http://localhost:8000');